
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.9.0'
version = '1.9.0'
full_version = '1.9.0'
git_revision = '07601a64cdfeb1c0247bde1294ad6380413cab66'
release = True

if not release:
    version = full_version
